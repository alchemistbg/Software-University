package projectrider.entity;

import javax.persistence.*;

@Entity
@Table(name = "projects")
public class Project {

    // TODO
}
