const Cat = require('../models').Cat;

module.exports = {
    index: (req, res) => {
         // TODO
    },

    createGet: (req, res) => {
           // TODO
    },

    createPost: (req, res) => {
        let args = req.body.cat;

        Cat.create(args).then(()=>{
            res.redirect('/');
        })

    },

    editGet: (req, res) => {
         // TODO
    },

    editPost: (req, res) => {
        // TODO
    },

    deleteGet: (req, res) => {
         // TODO
    },

    deletePost: (req, res) => {
        // TODO
    }
};
