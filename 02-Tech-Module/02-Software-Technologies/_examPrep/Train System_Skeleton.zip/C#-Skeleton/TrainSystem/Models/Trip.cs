﻿using System.ComponentModel.DataAnnotations;

namespace TrainSystem.Models
{
    public class Trip
    {
        // Implement me ...
    }
}