const mongoose = require('mongoose');

let tripSchema = mongoose.Schema({
    //TODO: Implement me ...
});

let Trip = mongoose.model('Trip', tripSchema);

module.exports = Trip;