package trainsystem.entity;

import javax.persistence.*;

@Entity
@Table(name = "trips")
public class Trip {
    //TODO: Implement me ...
}
