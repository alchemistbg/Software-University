package trainsystem.bindingModel;

public class TripBindingModel {
	//TODO: Implement me ...
}
