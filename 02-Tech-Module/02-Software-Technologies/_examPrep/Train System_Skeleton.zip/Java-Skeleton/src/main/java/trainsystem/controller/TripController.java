package trainsystem.controller;

import trainsystem.entity.Trip;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import trainsystem.bindingModel.TripBindingModel;
import trainsystem.repository.TripRepository;

import java.util.List;

@Controller
public class TripController {
	private final TripRepository tripRepository;

	@Autowired
	public TripController(tripRepository tripRepository) {
		this.tripRepository = tripRepository;
	}

	@GetMapping("/")
	public String index(Model model) {
		//TODO: Implement me ...
	}

	@GetMapping("/create")
	public String create(Model model) {
		//TODO: Implement me ...
	}

	@PostMapping("/create")
	public String createProcess(Model model, TripBindingModel tripBindingModel) {
		//TODO: Implement me ...
	}

	@GetMapping("/edit/{id}")
	public String edit(Model model, @PathVariable int id) {
		//TODO: Implement me ...
	}

	@PostMapping("/edit/{id}")
	public String editProcess(@PathVariable int id, Model model, TripBindingModel tripBindingModel) {
		//TODO: Implement me ...
	}

	@GetMapping("/delete/{id}")
	public String delete(Model model, @PathVariable int id) {
		//TODO: Implement me ...
	}

	@PostMapping("/delete/{id}")
	public String deleteProcess(@PathVariable int id, TripBindingModel tripBindingModel) {
		//TODO: Implement me ...
	}
}
