class F1SeasonApp:

	def __init__(self):
		...

	def register_team_for_season(self, team_name: str, budget: int):
		...

	def new_race_results(self, race_name: str, red_bull_pos: int, mercedes_pos: int):
		...
