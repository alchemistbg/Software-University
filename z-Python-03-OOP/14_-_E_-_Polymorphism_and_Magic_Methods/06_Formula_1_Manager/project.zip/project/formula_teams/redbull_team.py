from .formula_team import FormulaTeam

class RedBullTeam(FormulaTeam):
	pass
