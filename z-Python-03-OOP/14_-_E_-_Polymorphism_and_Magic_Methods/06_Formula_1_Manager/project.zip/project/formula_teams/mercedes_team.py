from .formula_team import FormulaTeam

class MercedesTeam(FormulaTeam):
	...
