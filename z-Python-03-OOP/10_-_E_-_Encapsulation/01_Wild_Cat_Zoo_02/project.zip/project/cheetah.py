from .animal import Animal


class Cheetah(Animal):
    pass
