from .animal import Animal


class Lion(Animal):
    pass
