from .animal import Animal


class Tiger(Animal):
    pass
