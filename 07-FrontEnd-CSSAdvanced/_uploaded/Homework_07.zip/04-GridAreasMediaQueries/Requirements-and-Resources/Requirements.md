﻿# 04 - Redefining grid with Media Queries
------
Problems for in-class lab for the [“CSS Advanced”](https://softuni.bg/trainings/2427/css-advanced-july-2019) course @ **SoftUni**.

## Tasks
* Copy the code from **Using Grid Named areas** - exercise 3
* Redefine the grid using Media Queries for the screen under 1024px width


