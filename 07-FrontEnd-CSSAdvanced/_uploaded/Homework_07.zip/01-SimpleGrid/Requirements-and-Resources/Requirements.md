﻿# 01 - Create a simple grid based layout
------
Problems for in-class lab for the [“CSS Advanced”](https://softuni.bg/trainings/2427/css-advanced-july-2019) course @ **SoftUni**.

## Tasks
* Create **index.html** file
* Use **div** tags to create the containers with letters inside
* Set to the body display property **grid**
* Define your grid. Open the screenshot to see how the containers get positioned in the grid
